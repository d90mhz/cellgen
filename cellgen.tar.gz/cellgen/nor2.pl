#!/usr/local/bin/perl -w


sub nor2	# parameters: lef filehandle, cell name, lambda, height, ratio, psize, nsize
{
	my $lefhandle = shift @_;

	my $cell_name = shift @_;
	my $lambda = shift @_;
	my $height = shift @_;
	my $ratio = shift @_;
	my $psize = shift @_;
	my $nsize = shift @_;
	
	my $pins = 3;
	my $min_height = 62;
	my $max_psize_min = 16;
	my $max_nsize_min = 16;
	
	my @coords = (0, 0, 0, 0);
	my @lcoords = (0, 0, 0, 0);
	my @ccoords = (0, 0, 0, 0);
	my ($delta_ph, $delta_nh, $pfolds, $nfolds, $max_folds, $psize_each, $nsize_each, $delta_width, $width)
	  = calc ($lambda, $height, $ratio, $pins, $min_height, $psize, $nsize, $max_psize_min, $max_nsize_min);

	print $lefhandle "MACRO $cell_name\n  CLASS CORE ;\n";
	@lcoords = lefcoords ($lambda, -52-$delta_width, -28-$delta_nh, -4, 28+$delta_ph);					# cell boundary
	printf $lefhandle "  FOREIGN $cell_name %.3f %.3f ;\n", $lcoords[0], $lcoords[1];
	printf $lefhandle "  ORIGIN %.3f %.3f ;\n", - $lcoords[0], - $lcoords[1];
	printf $lefhandle "  SIZE %.3f BY %.3f ;\n", $lcoords[2] - $lcoords[0], $lcoords[3] - $lcoords[1];
	print $lefhandle "  SYMMETRY X Y ;\n  SITE CoreSite ;\n";
	print $lefhandle "  PIN vdd!\n    DIRECTION INOUT ;\n    USE POWER ;\n    SHAPE ABUTMENT ;\n";
	print $lefhandle "    PORT\n    LAYER metal1 ;\n";
	@lcoords = lefcoords ($lambda, -52-$delta_width, 26+$delta_ph, -4, 30+$delta_ph);					# pin vdd!
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END vdd!\n  PIN gnd!\n    DIRECTION INOUT ;\n    USE GROUND ;\n    SHAPE ABUTMENT ;\n ";
	print $lefhandle "   PORT\n    LAYER metal1 ;\n";
	@lcoords = lefcoords ($lambda, -52-$delta_width, -30-$delta_nh, -4, -26-$delta_nh);					# pin gnd!
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END gnd!\n  PIN out\n    DIRECTION OUTPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -14, -2, -10, 2);									# pin out
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END out\n  PIN in0\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -30, -2, -26, 2);									# pin in0
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in0\n  PIN in1\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -46, -2, -42, 2);									# pin in1
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in1\n";

	## METAL2 SHIELD STRIPES AS PINS
	$i = 0;
	$j = 0;
	until ($i >= $width + 16)
	{
		print $lefhandle "  PIN shield_$j\n    DIRECTION INOUT ;\n    PORT\n    LAYER metal2 ;\n";
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -6-($i), -30-$delta_nh, -2-($i), 30+$delta_ph);			# shield stripes
		print $lefhandle "    END\n  END shield_$j\n";
		$j++;
		$i+=16;
	}

	print $lefhandle "  OBS\n";
	## NWELL
	print $lefhandle "    LAYER nwell ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -56-$delta_width, 0, 0, 34+$delta_ph);						# nwell
	## NSELECT
	print $lefhandle "    LAYER nselect ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -52-$delta_width, 24+$delta_ph, -4, 32+$delta_ph);				# vdd! select
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -52-$delta_width, -24-$delta_nh, -4, 0);					# nmos select
	## PSELECT
	print $lefhandle "    LAYER pselect ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -52-$delta_width, -32-$delta_nh, -4, -24-$delta_nh);				# gnd! select
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -52-$delta_width, 0, -4, 24+$delta_ph);					# pmos select
	## NACTIVE
	print $lefhandle "    LAYER nactive ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-$delta_width, 26+$delta_ph, -6, 30+$delta_ph);				# vdd! active
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(8*($nfolds*($pins-1))), -22-$delta_nh, -14, -22+$nsize_each-$delta_nh);	# nmos active
	## PACTIVE
	print $lefhandle "    LAYER pactive ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-$delta_width, -30-$delta_nh, -6, -26-$delta_nh);				# gnd! active
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(8*($pfolds*($pins-1))), 22-$psize_each+$delta_ph, -14, 22+$delta_ph);	# pmos active
	## POLY
	print $lefhandle "    LAYER poly ;\n";
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 2)
	{
		if (!(($i >= $max_folds * ($pins - 1)) && ($nfolds == 0) && ($pfolds == 0)))
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(8*$i), -2, -18-(8*$i), 2);				# poly contact pads
		}
		$i++;
	}
	$i = 0;
	until ($i == ($pfolds * ($pins - 1)) + 2)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), 2, -19-(8*$i), 24+$delta_ph);				# upper poly
		$i++;
	}
	$i = 0;
	until ($i == ($nfolds * ($pins - 1)) + 2)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), -24-$delta_nh, -19-(8*$i), -2);				# lower poly
		$i++;
	}
	## METAL1
	print $lefhandle "    LAYER metal1 ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -14, -11, -10, 11);								# out bridge
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 2)
	{
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(8*$i), -2, -18-(8*$i), 2);				# poly contact pads
		}
		$i++;
	}
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -18, 11, -10, 15);								# 0 fold upper out rail
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -18, -15, -10, -11);								# 0 fold lower out rail
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -18, 15, -14, 22+$delta_ph);							# 0 fold pmos out connect
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -18, -22-$delta_nh, -14, -15);							# 0 fold nmos out connect
	$i = 1;
	until ($i == $max_folds + 1)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(16*($i-1)), -2, -30-(16*($i-1)), 2);				# central pin rail
		if ($i % 2 == 0)
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -62-(16*($i-2)), -8, -34-(16*($i-2)), -5);			# in0 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -38-(16*($i-2)), -5, -34-(16*($i-2)), -2);			# in0 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -62-(16*($i-2)), -5, -58-(16*($i-2)), -2);			# in0 signal connect
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -46-(16*($i-1)), 5, -18-(16*($i-1)), 8);			# in1 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(16*($i-1)), 2, -18-(16*($i-1)), 5);			# in1 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -46-(16*($i-1)), 2, -42-(16*($i-1)), 5);			# in1 signal connect
		}
		$i++;
	}
	$i = 0;
	until ($i == $pfolds + 1)
	{
		if ($i % 2 == 0)
		{
			if (22+$delta_ph-$psize_each > 18)	# if active stops short of out rail
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -34-(16*$i), 22+$delta_ph-$psize_each, -30-(16*$i), 26+$delta_ph);				# vdd connects
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(16*$i), 18, -30-(16*$i), 26+$delta_ph);		# vdd connects
			}
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(16*($i-1)), 15, -46-(16*($i-1)), 22+$delta_ph);		# pmos out connects
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(16*($i-1)), 11, -18-(16*($i-1)), 15);			# pmos out rail
		}
		$i++;
	}
	$i = 0;
	until ($i == $nfolds + 1)
	{
		if (-22-$delta_nh+$nsize_each < -18)	# if active stops short of out rail
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
			  -26-(16*$i), -26-$delta_nh, -22-(16*$i), -22-$delta_nh+$nsize_each);					# gnd connects
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -26-(16*$i), -26-$delta_nh, -22-(16*$i), -18);			# gnd connects
		}
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(16*($i)), -22-$delta_nh, -30-(16*($i)), -15);			# nmos out connects
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(16*($i)), -15, -18-(16*($i)), -11);				# nmos out rail
		$i++;
	}
	## CP
	print $lefhandle "    LAYER cp ;\n";
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 2)
	{
		if (!(($i >= $max_folds * ($pins - 1)) && ($nfolds == 0) && ($pfolds == 0)))
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), -1, -19-(8*$i), 1);				# poly contacts
		}
		$i++;

	}
	## CA
	print $lefhandle "    LAYER ca ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -17, 19+$delta_ph, -15, 21+$delta_ph);						# 0 fold pmos out connect
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -17, -21-$delta_nh, -15, -19-$delta_nh);					# 0 fold nmos out connect
	$i = 0;
	until ($i >= $width)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -9-($i), 27+$delta_ph, -7-($i), 29+$delta_ph);				# vdd strapping
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -9-($i), -29-$delta_nh, -7-($i), -27-$delta_nh);			# gnd strapping
		$i+=8;
	}
	$i = 0;
	until ($i == $nfolds + 1)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -25-(16*$i), -21-$delta_nh, -23-(16*$i), -19-$delta_nh);		# vdd connects
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -33-(16*$i), -21-$delta_nh, -31-(16*$i), -19-$delta_nh);		# pmos out connects
		$i++;
	}
	$i = 0;
	until ($i == $pfolds + 1)
	{
		if ($i % 2 == 0)
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -33-(16*$i), 19+$delta_ph, -31-(16*$i), 21+$delta_ph);		# gnd connects
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
			  -49-(16*($i-1)), 19+$delta_ph, -47-(16*($i-1)), 21+$delta_ph);						# nmos out connects
		}
		$i++;
	}
	## VIA
	print $lefhandle "    LAYER via ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -13, -1, -11, 1);								# out pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -29, -1, -27, 1);								# in0 pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -45, -1, -43, 1);								# in1 pin

	printf $lefhandle "  END\nEND $cell_name\n";
}

1
