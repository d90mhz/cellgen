#!/usr/local/bin/perl -w


sub oai22	# parameters: lef filehandle, cell name, lambda, height, ratio, psize, nsize
{
	my $lefhandle = shift @_;
	my $cell_name = shift @_;
	my $lambda = shift @_;
	my $height = shift @_;
	my $ratio = shift @_;
	my $psize = shift @_;
	my $nsize = shift @_;
	
	my $pins = 5;
	my $min_height = 108;
	my $max_psize_min = 34;
	my $max_nsize_min = 34;
	
	my @coords = (0, 0, 0, 0);
	my @lcoords = (0, 0, 0, 0);
	my @ccoords = (0, 0, 0, 0);
	my ($delta_ph, $delta_nh, $pfolds, $nfolds, $max_folds, $psize_each, $nsize_each, $delta_width, $width)
	  = calc ($lambda, $height, $ratio, $pins, $min_height, $psize, $nsize, $max_psize_min, $max_nsize_min);

	print $lefhandle "MACRO $cell_name\n  CLASS CORE ;\n";
	@lcoords = lefcoords ($lambda, -84-$delta_width, -51-$delta_nh, -4, 51+$delta_ph);					# cell boundary
	printf $lefhandle "  FOREIGN $cell_name %.3f %.3f ;\n", $lcoords[0], $lcoords[1];
	printf $lefhandle "  ORIGIN %.3f %.3f ;\n", - $lcoords[0], - $lcoords[1];
	printf $lefhandle "  SIZE %.3f BY %.3f ;\n", $lcoords[2] - $lcoords[0], $lcoords[3] - $lcoords[1];
	print $lefhandle "  SYMMETRY X Y ;\n  SITE CoreSite ;\n";
	print $lefhandle "  PIN vdd!\n    DIRECTION INOUT ;\n    USE POWER ;\n    SHAPE ABUTMENT ;\n";
	print $lefhandle "    PORT\n    LAYER metal1 ;\n";
	@lcoords = lefcoords ($lambda, -84-$delta_width, 49+$delta_ph, -4, 53+$delta_ph);					# pin vdd!
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END vdd!\n  PIN gnd!\n    DIRECTION INOUT ;\n    USE GROUND ;\n    SHAPE ABUTMENT ;\n ";
	print $lefhandle "   PORT\n    LAYER metal1 ;\n";
	@lcoords = lefcoords ($lambda, -84-$delta_width, -53-$delta_nh, -4, -49-$delta_nh);					# pin gnd!
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END gnd!\n  PIN out\n    DIRECTION OUTPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -14, -2, -10, 2);									# pin out
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END out\n  PIN in3\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -30, -2, -26, 2);									# pin in0
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in3\n  PIN in2\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -46, -2, -42, 2);									# pin in1
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in2\n  PIN in0\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -62, -2, -58, 2);									# pin in2
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in0\n  PIN in1\n    DIRECTION INPUT ;\n    PORT\n    LAYER metal2 ;\n";
	@lcoords = lefcoords ($lambda, -78, -2, -74, 2);									# pin in3
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", $lcoords[0], $lcoords[1], $lcoords[2], $lcoords[3];
	print $lefhandle "    END\n  END in1\n";

	## METAL2 SHIELD STRIPES AS PINS
	$i = 0;
	$j = 0;
	until ($i >= $width + 16)
	{
		print $lefhandle "  PIN shield_$j\n    DIRECTION INOUT ;\n    PORT\n    LAYER metal2 ;\n";
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -6-($i), -53-$delta_nh, -2-($i), 53+$delta_ph);			# shield stripes
		print $lefhandle "    END\n  END shield_$j\n";
		$j++;
		$i+=16;
	}

	print $lefhandle "  OBS\n";
	## NWELL
	print $lefhandle "    LAYER nwell ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -88-$delta_width, 0, 0, 57+$delta_ph);					# nwell
	## NSELECT
	print $lefhandle "    LAYER nselect ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -84-$delta_width, 47+$delta_ph, -4, 55+$delta_ph);				# vdd! select
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -84-$delta_width, -47-$delta_nh, -4, 0);					# nmos select
	## PSELECT
	print $lefhandle "    LAYER pselect ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -84-$delta_width, -55-$delta_nh, -4, -47-$delta_nh);				# gnd! select
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -84-$delta_width, 0, -4, 47+$delta_ph);					# pmos select
	## NACTIVE
	print $lefhandle "    LAYER nactive ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -82-$delta_width, 49+$delta_ph, -6, 53+$delta_ph);				# vdd! active
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(8*($nfolds*($pins-1))), -40-$delta_nh, -14, -40+$nsize_each-$delta_nh);	# nmos active
	## PACTIVE
	print $lefhandle "    LAYER pactive ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -82-$delta_width, -53-$delta_nh, -6, -49-$delta_nh);				# gnd! active
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(8*($pfolds*($pins-1))), 40-$psize_each+$delta_ph, -14, 40+$delta_ph);	# pmos active
	## POLY
	print $lefhandle "    LAYER poly ;\n";
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 4)
	{
		if (!(($i >= $max_folds * ($pins - 1)) && ($nfolds == 0) && ($pfolds == 0)))
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(8*$i), -2, -18-(8*$i), 2);				# poly contact pads
		}
		$i++;
	}
	$i = 0;
	until ($i == ($pfolds * ($pins - 1)) + 4)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), 2, -19-(8*$i), 42+$delta_ph);				# upper poly
		$i++;
	}
	$i = 0;
	until ($i == ($nfolds * ($pins - 1)) + 4)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), -42-$delta_nh, -19-(8*$i), -2);				# lower poly
		$i++;
	}
	## METAL1
	print $lefhandle "    LAYER metal1 ;\n";
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 4)
	{
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(8*$i), -2, -18-(8*$i), 2);				# poly contact pads
		}
		$i++;
	}
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -14, -23, -10, 23);								# out bridge
	$i = 1;
	until ($i == $max_folds + 1)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(32*($i-1)), -2, -46-(32*($i-1)), 2);				# central pin rail
		if ($i % 2 == 0)
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -110-(32*($i-2)), -20, -50-(32*($i-2)), -17);			# in1 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -54-(32*($i-2)), -17, -50-(32*($i-2)), -2);			# in1 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -110-(32*($i-2)), -17, -106-(32*($i-2)), -2);			# in1 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -102-(32*($i-2)), -14, -58-(32*($i-2)), -11);			# in2 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -62-(32*($i-2)), -11, -58-(32*($i-2)), -2);			# in2 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -102-(32*($i-2)), -11, -98-(32*($i-2)), -2);			# in2 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -94-(32*($i-2)), -8, -66-(32*($i-2)), -5);			# in0 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -70-(32*($i-2)), -5, -66-(32*($i-2)), -2);			# in0 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -94-(32*($i-2)), -5, -90-(32*($i-2)), -2);			# in0 signal conn
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -78-(32*($i-1)), 17, -18-(32*($i-1)), 20);			# in3 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -22-(32*($i-1)), 2, -18-(32*($i-1)), 17);			# in3 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -78-(32*($i-1)), 2, -74-(32*($i-1)), 17);			# in3 signal conn
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -70-(32*($i-1)), 11, -26-(32*($i-1)), 14);			# in0 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -30-(32*($i-1)), 2, -26-(32*($i-1)), 11);			# in0 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -70-(32*($i-1)), 2, -66-(32*($i-1)), 11);			# in0 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -62-(32*($i-1)), 5, -34-(32*($i-1)), 8);			# in2 signal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -38-(32*($i-1)), 2, -34-(32*($i-1)), 5);			# in2 signal connect
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -62-(32*($i-1)), 2, -58-(32*($i-1)), 5);			# in2 signal connect

		}
		$i++;
	}
	$i = 0;
	until ($i == $pfolds + 1)
	{
		if ($i == 0)
		{
			if (40+$delta_ph-$psize_each > 30)	# if active stops short of out rail
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -18, 40+$delta_ph-$psize_each, -14, 49+$delta_ph);										# vdd connects
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -18, 30, -14, 49+$delta_ph);													# vdd connects
			}
		}
		if (40+$delta_ph-$psize_each > 30)	# if active stops short of out rail
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
			  -50-(32*$i), 40+$delta_ph-$psize_each, -46-(32*$i), 49+$delta_ph);									# vdd connects
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(32*$i), 30, -46-(32*$i), 49+$delta_ph);			# vdd connects
		}
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(32*($i)), 27, -30-(32*($i)), 40+$delta_ph);			# pmos out connects
		if ($i == 0)
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34, 23, -10, 27);						# pmos out rail
		}
		else
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -66-(32*($i-1)), 23, -34-(32*($i-1)), 27);			# pmos out rail
		}
		$i++;
	}
	$i = 0;
	until ($i == $nfolds + 1)
	{
		if ($i % 2 == 0)
		{
			if (-40-$delta_nh+$nsize_each < -36)	# if active stops short of internal rail
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -42-(32*$i), -49-$delta_nh, -38-(32*$i), -40-$delta_nh+$nsize_each);								# gnd connects
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -42-(32*$i), -49-$delta_nh, -38-(32*$i), -36);	# gnd connects
			}
			if ($i == 0)
			{
				if (-40-$delta_nh+$nsize_each < -30)	# if active stops short of internal rail
				{
					printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
					  -18, -43-$delta_nh, -14, -40-$delta_nh+$nsize_each);									# internal connects
				}
				else
				{
					printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
					  -18, -43-$delta_nh, -14, -30);											# internal connects
				}
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -26, -27, -10, -23);					# nmos out rail
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -34, -46-$delta_nh, -14, -43-$delta_nh);											# upper internal rail
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -26-(32*$i), -27, -10-(32*$i), -23);			# nmos out rail
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -34-(32*$i), -46-$delta_nh, -18-(32*$i), -43-$delta_nh);									# upper internal rail
			}
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -26-(32*$i), -40-$delta_nh, -22-(32*$i), -27);		# nmos out connects
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(32*$i), -40-$delta_nh, -46-(32*$i), -33);		# internal connects
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -50-(32*$i), -33, -30-(32*$i), -30);				# lower internal rail
		}
		else
		{
			if (-40-$delta_nh+$nsize_each < -36)	# if active stops short of internal rail
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -58-(32*($i-1)), -49-$delta_nh, -54-(32*($i-1)), -40-$delta_nh+$nsize_each);							# gnd connects
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -58-(32*($i-1)), -49-$delta_nh, -54-(32*($i-1)), -36);									# gnd connects
			}
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -74-(32*($i-1)), -40-$delta_nh, -70-(32*($i-1)), -27);	# nmos out connects
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -74-(32*($i-1)), -27, -26-(32*($i-1)), -23);			# nmos out rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -66-(32*($i-1)), -33, -50-(32*($i-1)), -30);			# lower internal rail
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
			  -82-(32*($i-1)), -46-$delta_nh, -62-(32*($i-1)), -43-$delta_nh);									# upper internal rail
			if (-40-$delta_nh+$nsize_each < -30)	# if active stops short of internal rail
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -82, -43-$delta_nh, -78, -40-$delta_nh+$nsize_each);										# internal connects
			}
			else
			{
				printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda,
				  -82, -43-$delta_nh, -78, -30);												# internal connects
			}
		}
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -34-(32*($i)), -43-$delta_nh, -30-(32*($i)), -33);			# internal connects
		$i++;
	}
	## CP
	print $lefhandle "    LAYER cp ;\n";
	$i = 0;
	until ($i == ($max_folds * ($pins - 1)) + 4)
	{
		if (!(($i >= $max_folds * ($pins - 1)) && ($nfolds == 0) && ($pfolds == 0)))
		{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -21-(8*$i), -1, -19-(8*$i), 1);				# poly contacts
		}
		$i++;

	}
	## CA
	print $lefhandle "    LAYER ca ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -17, 37+$delta_ph, -15, 39+$delta_ph);					# 0 fold pmos out connect
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -17, -39-$delta_nh, -15, -37-$delta_nh);					# 0 fold nmos out connect
	$i = 0;
	until ($i >= $width)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -9-($i), 50+$delta_ph, -7-($i), 52+$delta_ph);			# vdd strapping
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -9-($i), -52-$delta_nh, -7-($i), -50-$delta_nh);			# gnd strapping
		$i+=8;
	}
	$i = 0;
	until ($i == $pfolds + 1)
	{
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -33-(32*$i), 37+$delta_ph, -31-(32*$i), 39+$delta_ph);	# pmos out connects
			printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -49-(32*$i), 37+$delta_ph, -47-(32*$i), 39+$delta_ph);	# vdd connects
		$i++;
	}
	$i = 0;
	until ($i == $nfolds + 1)
	{
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -41-(32*$i), -39-$delta_nh, -39-(32*$i), -37-$delta_nh);		# gnd connects
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -25-(32*$i), -39-$delta_nh, -23-(32*$i), -37-$delta_nh);		# gnd connects
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -49-(32*$i), -39-$delta_nh, -47-(32*$i), -37-$delta_nh);		# nmos out connects
		printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -33-(32*$i), -39-$delta_nh, -31-(32*$i), -37-$delta_nh);		# nmos out connects
		$i++;
	}
	## VIA
	print $lefhandle "    LAYER via ;\n";
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -13, -1, -11, 1);								# out pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -29, -1, -27, 1);								# in0 pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -45, -1, -43, 1);								# in1 pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -61, -1, -59, 1);								# in2 pin
	printf $lefhandle "    RECT %.3f %.3f %.3f %.3f ;\n", lefcoords ($lambda, -77, -1, -75, 1);								# in3 pin

	printf $lefhandle "  END\nEND $cell_name\n";
}

1
